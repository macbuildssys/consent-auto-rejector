console.log("Background worker running");
//# sourceMappingURL=service.js.map